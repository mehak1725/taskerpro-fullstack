export const MOCK_USERS = [
  { id: '1', name: 'Alex Rivera', role: 'Lead Architect', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop' },
  { id: '2', name: 'Sarah Chen', role: 'Senior Engineer', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop' },
  { id: '3', name: 'James Wilson', role: 'Product Manager', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop' },
  { id: '4', name: 'Elena Rostova', role: 'UX Designer', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop' },
  { id: '5', name: 'David Kim', role: 'DevOps', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop' },
];

export const MOCK_PROJECTS = [
  { id: 'p1', name: 'Nova Core Redesign', status: 'In Progress', health: 'On Track', progress: 68, team: ['1', '2', '4'], deadline: '2026-06-15', tasksCompleted: 45, tasksTotal: 66 },
  { id: 'p2', name: 'Quantum Analytics Engine', status: 'Planning', health: 'At Risk', progress: 15, team: ['1', '3', '5'], deadline: '2026-07-01', tasksCompleted: 12, tasksTotal: 80 },
  { id: 'p3', name: 'Nexus API v2', status: 'Review', health: 'On Track', progress: 92, team: ['2', '3'], deadline: '2026-05-20', tasksCompleted: 110, tasksTotal: 120 },
  { id: 'p4', name: 'Infrastructure Scaling', status: 'In Progress', health: 'Warning', progress: 45, team: ['1', '5'], deadline: '2026-06-30', tasksCompleted: 15, tasksTotal: 34 },
];

export const MOCK_TASKS = [
  { id: 't1', projectId: 'p1', title: 'Implement Redis caching layer for feed', status: 'In Progress', priority: 'High', assigneeId: '1', dueDate: '2026-05-20', tags: ['Backend', 'Performance'] },
  { id: 't2', projectId: 'p1', title: 'Migrate component library to Tailwind v4', status: 'Todo', priority: 'Medium', assigneeId: '2', dueDate: '2026-05-22', tags: ['Frontend', 'Tech Debt'] },
  { id: 't3', projectId: 'p2', title: 'Design Database Schema for Analytics', status: 'Completed', priority: 'High', assigneeId: '3', dueDate: '2026-05-10', tags: ['Database', 'Planning'] },
  { id: 't4', projectId: 'p1', title: 'Refine Dark Mode accessible contrast', status: 'Review', priority: 'Low', assigneeId: '4', dueDate: '2026-05-16', tags: ['Design', 'A11y'] },
  { id: 't5', projectId: 'p3', title: 'Write OAuth2 implementation documentation', status: 'Todo', priority: 'Medium', assigneeId: '3', dueDate: '2026-05-25', tags: ['Docs', 'API'] },
  { id: 't6', projectId: 'p4', title: 'Kubernetes cluster auto-scaling rules', status: 'In Progress', priority: 'Urgent', assigneeId: '5', dueDate: '2026-05-18', tags: ['DevOps', 'Infrastructure'] },
];

export const ACTIVITY_TIMELINE = [
  { id: 'a1', userId: '2', action: 'pushed 3 commits to', target: 'Nexus API v2', time: '12 mins ago', type: 'code' },
  { id: 'a2', userId: '4', action: 'attached new design files to', target: 'Dark Mode accessible contrast', time: '1 hour ago', type: 'design' },
  { id: 'a3', userId: '1', action: 'resolved critical bug in', target: 'Redis caching layer', time: '3 hours ago', type: 'bug' },
  { id: 'a4', userId: '5', action: 'updated environment variables for', target: 'Infrastructure Scaling', time: '5 hours ago', type: 'system' },
  { id: 'a5', userId: '3', action: 'moved to In Progress:', target: 'Write OAuth2 implementation documentation', time: '1 day ago', type: 'status' },
];

export const AI_INSIGHTS = [
  { id: 'i1', title: 'Velocity Warning', description: 'The Quantum Analytics Engine project is at risk. Sprint velocity has dropped by 24% over the last week. Suggest reallocating 1 backend engineer.', type: 'warning' },
  { id: 'i2', title: 'Optimization Found', description: 'Based on recent task completions, Sarah Chen is completing API tasks 40% faster than average. Consider assigning the pending Webhook integration to her.', type: 'positive' },
];

export const SPRINT_METRICS = [
  { day: 'Mon', capacity: 100, actual: 85 },
  { day: 'Tue', capacity: 100, actual: 110 },
  { day: 'Wed', capacity: 100, actual: 95 },
  { day: 'Thu', capacity: 100, actual: 120 },
  { day: 'Fri', capacity: 100, actual: 105 },
  { day: 'Sat', capacity: 40, actual: 15 },
  { day: 'Sun', capacity: 40, actual: 0 },
];

export const WORKLOAD_DATA = [
  { subject: 'Backend', A: 120, fullMark: 150 },
  { subject: 'Frontend', A: 98, fullMark: 150 },
  { subject: 'DevOps', A: 86, fullMark: 150 },
  { subject: 'Design', A: 65, fullMark: 150 },
  { subject: 'Planning', A: 85, fullMark: 150 },
  { subject: 'QA', A: 45, fullMark: 150 },
];
