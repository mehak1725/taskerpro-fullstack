import { Link, useNavigate } from "react-router";
import { ArrowRight, Eye, EyeOff } from "lucide-react";
import { useState } from "react";

export default function SignupPage() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/app/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-[#03050a] px-4">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="w-full max-w-md bg-[#080b14]/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-8 relative z-10">
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-cyan-600/20 flex items-center justify-center border border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.3)] mb-4">
            <div className="w-5 h-5 bg-cyan-400 rounded-sm" />
          </div>
          <h2 className="text-2xl font-display font-bold text-white tracking-wide">INITIALIZE PROFILE</h2>
          <p className="text-slate-400 text-sm mt-2">Join the Nexus network</p>
        </div>

        <form onSubmit={handleSignup} className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold tracking-wider text-slate-400 uppercase">Full Name</label>
            <input 
              type="text" 
              className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/50 focus:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all"
              placeholder="John Doe"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold tracking-wider text-slate-400 uppercase">Email</label>
            <input 
              type="email" 
              className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/50 focus:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all"
              placeholder="agent@nexus.io"
              required
            />
          </div>
          
          <div className="space-y-2 relative">
            <label className="text-xs font-semibold tracking-wider text-slate-400 uppercase">Password</label>
            <div className="relative">
              <input 
                type={showPassword ? "text" : "password"} 
                className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 pr-10 text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500/50 focus:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all"
                placeholder="••••••••"
                required
              />
              <button 
                type="button" 
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full mt-6 flex items-center justify-center gap-2 py-3.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all"
          >
            Create Account
            <ArrowRight size={18} />
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-slate-400">
          Already registered? <Link to="/login" className="text-cyan-400 hover:text-cyan-300 ml-1">Login here</Link>
        </div>
      </div>
    </div>
  );
}
