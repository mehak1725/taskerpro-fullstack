import { Bell, Shield, User, Palette, Key, Database } from "lucide-react";

export default function SettingsPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold text-white mb-2">System Configurations</h1>
        <p className="text-slate-400">Manage your preferences and security parameters.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Settings Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0 space-y-1">
          {[
            { id: 'profile', label: 'Profile', icon: User, active: true },
            { id: 'security', label: 'Security', icon: Shield, active: false },
            { id: 'notifications', label: 'Notifications', icon: Bell, active: false },
            { id: 'appearance', label: 'Appearance', icon: Palette, active: false },
            { id: 'api', label: 'API Keys', icon: Key, active: false },
            { id: 'data', label: 'Data Management', icon: Database, active: false },
          ].map((item) => (
            <button
              key={item.id}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm font-medium ${
                item.active 
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-[inset_0_0_15px_rgba(59,130,246,0.05)]' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/5 border border-transparent'
              }`}
            >
              <item.icon size={16} />
              {item.label}
            </button>
          ))}
        </div>

        {/* Settings Content */}
        <div className="flex-1 space-y-6">
          <div className="bg-[#080b14]/50 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-display font-semibold text-white mb-6">Operative Profile</h3>
            
            <div className="flex items-center gap-6 mb-8">
              <div className="w-24 h-24 rounded-full border border-blue-500/30 overflow-hidden relative group cursor-pointer">
                <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop" alt="Profile" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-xs text-white font-medium">Change</span>
                </div>
              </div>
              <div>
                <h4 className="text-white font-medium mb-1">Avatar</h4>
                <p className="text-xs text-slate-400 mb-3">Recommended size 256x256px. Max 2MB.</p>
                <div className="flex gap-2">
                  <button className="px-3 py-1.5 bg-white/10 hover:bg-white/15 text-white text-xs font-medium rounded-lg transition-colors border border-white/10">Upload New</button>
                  <button className="px-3 py-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 text-xs font-medium rounded-lg transition-colors">Remove</button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-semibold tracking-wider text-slate-400 uppercase">First Name</label>
                  <input type="text" defaultValue="Alex" className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500/50 transition-all" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-semibold tracking-wider text-slate-400 uppercase">Last Name</label>
                  <input type="text" defaultValue="Rivera" className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500/50 transition-all" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold tracking-wider text-slate-400 uppercase">Email Address</label>
                <input type="email" defaultValue="alex.rivera@nexus.io" className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-slate-400 focus:outline-none cursor-not-allowed" disabled />
                <p className="text-xs text-slate-500">To change your email, please contact a system administrator.</p>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold tracking-wider text-slate-400 uppercase">Bio / Status</label>
                <textarea rows={3} defaultValue="Lead Systems Engineer. Currently working on Quantum Analytics." className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500/50 transition-all resize-none" />
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-white/5 flex justify-end">
              <button className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-[0_0_15px_rgba(59,130,246,0.3)] transition-all font-medium text-sm">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
