import { useParams, Link } from "react-router";
import { ArrowLeft, Plus, MoreHorizontal, Calendar, Search, Filter, Hash, MessageSquare, Paperclip } from "lucide-react";
import { MOCK_PROJECTS, MOCK_TASKS, MOCK_USERS } from "../data/mock";

const COLUMNS = ['Todo', 'In Progress', 'Review', 'Completed'];

export default function ProjectDetailsPage() {
  const { id } = useParams();
  const project = MOCK_PROJECTS.find(p => p.id === id);
  const tasks = MOCK_TASKS.filter(t => t.projectId === id);

  if (!project) return <div className="text-white p-6">Project not found.</div>;

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col pb-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 shrink-0">
        <div className="flex items-center gap-4">
          <Link to="/app/projects" className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors border border-white/5">
            <ArrowLeft size={18} />
          </Link>
          <div>
            <div className="flex items-center gap-3">
               <h1 className="text-2xl font-display font-bold text-white leading-tight">{project.name}</h1>
               <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider bg-white/5 border border-white/10 text-slate-300">{project.id}</span>
            </div>
            <div className="flex items-center gap-2 mt-1">
               <span className="text-[10px] text-blue-400 font-medium uppercase tracking-wider">Kanban Board</span>
               <div className="w-1 h-1 rounded-full bg-slate-600" />
               <span className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">{tasks.length} Active Nodes</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="hidden lg:flex items-center bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 w-64 focus-within:border-blue-500/50 transition-all shadow-inner">
            <Search size={14} className="text-slate-500" />
            <input type="text" placeholder="Filter nodes..." className="bg-transparent border-none outline-none ml-2 w-full text-xs text-slate-300 placeholder:text-slate-600" />
          </div>
          <button className="p-2 bg-white/5 border border-white/10 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors">
            <Filter size={16} />
          </button>
          
          <div className="w-px h-6 bg-white/10 mx-1 hidden md:block" />
          
          <div className="flex -space-x-2 mr-1">
            {project.team.map((userId, i) => {
              const user = MOCK_USERS.find(u => u.id === userId);
              return (
                <div key={i} className="w-8 h-8 rounded-full border border-[#010205] overflow-hidden bg-black ring-1 ring-white/10 relative z-10 hover:z-20 hover:scale-110 transition-all">
                  <img src={user?.avatar} alt={user?.name} className="w-full h-full object-cover" />
                </div>
              );
            })}
            <button className="w-8 h-8 rounded-full border border-[#010205] flex items-center justify-center bg-white/5 text-slate-400 hover:text-white ring-1 ring-white/10 ring-dashed relative z-0 backdrop-blur-sm transition-colors">
              <Plus size={14} />
            </button>
          </div>
          <button className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-[0_0_20px_rgba(59,130,246,0.3)] transition-all font-medium text-xs border border-blue-500/50 ml-2">
            <Plus size={14} />
            Deploy Task
          </button>
        </div>
      </div>

      {/* Kanban Board Area */}
      <div className="flex-1 overflow-x-auto overflow-y-hidden scrollbar-hide border-t border-white/5 pt-6">
        <div className="flex gap-6 h-full min-w-max pb-4">
          {COLUMNS.map(column => (
            <div key={column} className="w-[340px] flex flex-col h-full bg-[#080b14]/40 backdrop-blur-xl rounded-2xl border border-white/5 shadow-lg">
              
              <div className="p-4 flex justify-between items-center border-b border-white/5">
                <div className="flex items-center gap-3">
                  <h3 className="font-display font-semibold text-slate-200 text-sm tracking-wide">{column}</h3>
                  <span className="px-2 py-0.5 rounded-full bg-black/40 border border-white/10 text-[10px] font-bold text-slate-400">
                    {tasks.filter(t => t.status === column).length}
                  </span>
                </div>
                <button className="text-slate-500 hover:text-white p-1 hover:bg-white/5 rounded transition-colors">
                  <Plus size={16} />
                </button>
              </div>

              <div className="flex-1 p-3 space-y-3 overflow-y-auto scrollbar-hide">
                {tasks.filter(t => t.status === column).map(task => {
                  const assignee = MOCK_USERS.find(u => u.id === task.assigneeId);
                  const isHigh = task.priority === 'High' || task.priority === 'Urgent';
                  
                  return (
                    <div 
                      key={task.id}
                      className="group relative bg-[#010205]/80 backdrop-blur-md border border-white/10 hover:border-blue-500/50 rounded-xl p-4 cursor-grab active:cursor-grabbing hover:shadow-[0_10px_30px_rgba(59,130,246,0.15)] transition-all duration-300"
                    >
                      {/* Neon edge highlight on hover */}
                      <div className="absolute top-0 left-0 w-1 h-full bg-blue-500 rounded-l-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-[0_0_10px_rgba(59,130,246,0.8)]" />
                      
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex gap-2">
                           <span className="flex items-center gap-1 text-[10px] uppercase font-bold tracking-wider text-slate-500">
                             <Hash size={10}/> {task.id}
                           </span>
                           <span className={`text-[9px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded border ${
                             isHigh ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 
                             task.priority === 'Medium' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 
                             'bg-slate-500/10 text-slate-400 border-slate-500/20'
                           }`}>
                             {task.priority}
                           </span>
                        </div>
                        <button className="text-slate-600 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                          <MoreHorizontal size={16} />
                        </button>
                      </div>
                      
                      <p className="text-slate-200 font-medium text-sm mb-4 leading-snug group-hover:text-white transition-colors">{task.title}</p>
                      
                      <div className="flex flex-wrap gap-1.5 mb-4">
                         {task.tags.map(tag => (
                           <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 border border-white/5 text-slate-400 group-hover:bg-blue-500/10 group-hover:border-blue-500/20 group-hover:text-blue-300 transition-colors">
                             {tag}
                           </span>
                         ))}
                      </div>
                      
                      <div className="flex items-center justify-between mt-auto pt-3 border-t border-white/5">
                        <div className="flex items-center gap-3 text-[10px] text-slate-500 font-medium">
                          <div className={`flex items-center gap-1.5 ${isHigh ? 'text-rose-400/80' : ''}`}>
                            <Calendar size={12} />
                            <span>{task.dueDate}</span>
                          </div>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                             <MessageSquare size={12}/> 2
                          </div>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                             <Paperclip size={12}/> 1
                          </div>
                        </div>
                        <div className="w-6 h-6 rounded-full border border-white/10 overflow-hidden bg-black ring-1 ring-transparent group-hover:ring-blue-500/30 transition-all">
                          <img src={assignee?.avatar} alt={assignee?.name} className="w-full h-full object-cover" />
                        </div>
                      </div>
                    </div>
                  );
                })}
                
                {/* Empty State / Add Task Dropzone */}
                <button className="w-full py-3 border border-white/5 border-dashed rounded-xl text-[11px] font-medium text-slate-500 hover:text-slate-300 hover:bg-white/5 hover:border-white/20 transition-all flex items-center justify-center gap-2">
                   <Plus size={12}/> Add Node
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
