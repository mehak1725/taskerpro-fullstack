import { Link } from "react-router";
import { ArrowRight, Activity, Shield, Zap, Terminal, Code2, Cpu } from "lucide-react";
import { motion } from "motion/react";

export default function LandingPage() {
  return (
    <div className="relative min-h-screen flex flex-col overflow-hidden bg-[#010205] selection:bg-blue-500/30">
      {/* Background Deep Glows */}
      <div className="absolute top-[-20%] left-1/2 -translate-x-1/2 w-[80vw] h-[80vw] bg-blue-900/10 rounded-full blur-[150px] pointer-events-none mix-blend-screen" />
      <div className="absolute top-[20%] right-[-10%] w-[50vw] h-[50vw] bg-cyan-900/10 rounded-full blur-[120px] pointer-events-none mix-blend-screen" />
      
      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMCAwaDQwdjQwSDBWMHptMjAgMjB2MjBoMjBWMjBIMjB6IiBmaWxsPSIjMWUzYTg1IiBmaWxsLW9wYWNpdHk9IjAuMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==')] opacity-30 pointer-events-none mix-blend-screen" />

      {/* Navbar */}
      <header className="container mx-auto px-6 py-6 flex items-center justify-between relative z-50">
        <div className="flex items-center gap-3">
          <div className="relative w-8 h-8 rounded-lg bg-blue-600/20 flex items-center justify-center border border-blue-500/50 shadow-[0_0_15px_rgba(59,130,246,0.5)] overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-transparent" />
            <div className="w-3 h-3 bg-blue-400 rounded-[2px] shadow-[0_0_10px_rgba(59,130,246,1)]" />
          </div>
          <span className="font-display font-bold text-2xl tracking-[0.2em] text-white">NEXUS</span>
        </div>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400 bg-white/5 px-6 py-2.5 rounded-full border border-white/10 backdrop-blur-md">
          <a href="#features" className="hover:text-white transition-colors">Features</a>
          <a href="#workflows" className="hover:text-white transition-colors">Workflows</a>
          <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
        </nav>
        <div className="flex items-center gap-4">
          <Link to="/login" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">
            Log in
          </Link>
          <Link to="/signup" className="group relative text-sm font-medium px-6 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white transition-all overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-white/20 to-blue-400/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
            <span className="relative z-10">Get Started</span>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center pt-24 px-6 relative z-10 w-full max-w-[1400px] mx-auto">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-900/20 border border-blue-500/30 text-blue-300 text-xs font-semibold tracking-wide mb-8 backdrop-blur-md shadow-[0_0_20px_rgba(59,130,246,0.15)]"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
          </span>
          NEXUS ENGINE V2.0 ONLINE
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: "easeOut" }}
          className="text-5xl md:text-7xl lg:text-[84px] font-display font-bold tracking-tight text-center max-w-5xl leading-[1.1]"
        >
          <span className="text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.1)]">Synchronize Your Team's</span><br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-300 to-blue-500 drop-shadow-[0_0_40px_rgba(59,130,246,0.3)]">
            Velocity & Vision
          </span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
          className="mt-8 text-lg md:text-xl text-slate-400 max-w-2xl text-center font-light leading-relaxed"
        >
          Experience the next generation of project management. Built for high-performing engineering and design teams who demand precision, speed, and absolute elegance.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
          className="mt-12 flex flex-col sm:flex-row items-center gap-6"
        >
          <Link to="/signup" className="group relative flex items-center gap-2 px-8 py-4 rounded-full bg-white text-black font-semibold shadow-[0_0_40px_rgba(255,255,255,0.2)] transition-all hover:scale-105">
            Initialize Workspace
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <Link to="/app" className="flex items-center gap-2 px-8 py-4 rounded-full bg-white/5 hover:bg-white/10 text-white font-medium border border-white/10 backdrop-blur-md transition-all shadow-lg hover:shadow-[0_0_20px_rgba(255,255,255,0.05)]">
            Enter Command Center
            <Terminal size={18} className="text-slate-400" />
          </Link>
        </motion.div>

        {/* Cinematic Dashboard Showcase */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
          className="w-full mt-24 relative perspective-[2000px]"
        >
          <div className="absolute inset-0 bg-gradient-to-t from-[#010205] via-transparent to-transparent z-20 pointer-events-none" />
          
          <div className="relative transform rotateX-[5deg] scale-[1.02] shadow-[0_0_100px_rgba(59,130,246,0.15)] rounded-2xl border border-white/10 bg-[#080b14]/90 backdrop-blur-2xl overflow-hidden group">
            
            {/* Ambient reflections on the mockup */}
            <div className="absolute inset-0 bg-gradient-to-tr from-white/[0.03] to-transparent pointer-events-none" />
            <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />
            
            <img 
              src="https://images.unsplash.com/photo-1709377195538-5522ed0f9e10?w=1600&h=900&fit=crop" 
              alt="Nexus Dashboard Background" 
              className="w-full h-[600px] object-cover opacity-30 mix-blend-screen"
            />

            {/* Simulated UI Overlay to make it look like a real app */}
            <div className="absolute inset-0 z-10 p-6 flex gap-6">
              {/* Fake Sidebar */}
              <div className="w-64 h-full bg-black/40 border border-white/5 rounded-xl backdrop-blur-xl p-4 flex flex-col gap-4">
                <div className="flex gap-2 items-center mb-4">
                  <div className="w-6 h-6 rounded bg-blue-500/30 border border-blue-500/50" />
                  <div className="h-4 w-24 bg-white/20 rounded" />
                </div>
                {[1,2,3,4,5].map(i => (
                  <div key={i} className="h-8 w-full bg-white/5 rounded-md" />
                ))}
              </div>
              
              {/* Fake Main Area */}
              <div className="flex-1 flex flex-col gap-6">
                <div className="h-16 w-full bg-black/40 border border-white/5 rounded-xl backdrop-blur-xl flex items-center px-4 justify-between">
                  <div className="h-6 w-64 bg-white/10 rounded-md" />
                  <div className="flex gap-2">
                    <div className="h-8 w-8 rounded-full bg-white/10" />
                    <div className="h-8 w-8 rounded-full bg-white/10" />
                  </div>
                </div>

                <div className="flex gap-6 flex-1">
                  <div className="flex-1 bg-black/40 border border-white/5 rounded-xl backdrop-blur-xl p-6 flex flex-col gap-6">
                    <div className="h-8 w-48 bg-white/10 rounded-md" />
                    <div className="flex-1 bg-gradient-to-t from-blue-500/20 to-transparent rounded-lg border border-blue-500/20" />
                  </div>
                  <div className="w-80 flex flex-col gap-6">
                    <div className="h-48 bg-black/40 border border-white/5 rounded-xl backdrop-blur-xl p-4">
                      <div className="h-6 w-32 bg-white/10 rounded-md mb-4" />
                      <div className="space-y-2">
                        {[1,2,3].map(i => <div key={i} className="h-8 w-full bg-white/5 rounded" />)}
                      </div>
                    </div>
                    <div className="flex-1 bg-black/40 border border-white/5 rounded-xl backdrop-blur-xl p-4">
                      <div className="h-32 w-32 rounded-full border-[8px] border-cyan-500/30 mx-auto mt-8 border-t-cyan-400" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Glass Widgets for extreme futuristic feel */}
            <motion.div 
              animate={{ y: [0, -15, 0] }}
              transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
              className="absolute top-1/4 -left-12 w-64 p-4 bg-[#080b14]/80 border border-white/10 backdrop-blur-2xl rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] z-30 hidden lg:block"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400"><Activity size={16}/></div>
                <div>
                  <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Velocity</div>
                  <div className="text-white font-bold">+24.5%</div>
                </div>
              </div>
              <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="w-[75%] h-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]" />
              </div>
            </motion.div>

            <motion.div 
              animate={{ y: [0, 15, 0] }}
              transition={{ repeat: Infinity, duration: 7, ease: "easeInOut", delay: 1 }}
              className="absolute bottom-1/4 -right-12 w-72 p-5 bg-[#080b14]/80 border border-white/10 backdrop-blur-2xl rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] z-30 hidden lg:block"
            >
              <div className="text-xs text-cyan-400 font-semibold uppercase tracking-wider mb-2 flex items-center gap-2">
                <Cpu size={14}/> AI Insight
              </div>
              <div className="text-sm text-slate-200 leading-relaxed">
                Reallocating 2 engineers to <span className="text-white font-medium">Core API</span> will reduce sprint delay by 4 days.
              </div>
            </motion.div>

          </div>
        </motion.div>

        {/* Feature Grid */}
        <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-6 mt-32 mb-32 z-20">
           <div className="group p-8 rounded-3xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] hover:border-blue-500/30 transition-all duration-500 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <Activity className="text-blue-400 mb-6 relative z-10" size={32} />
              <h3 className="text-xl font-display font-semibold text-white mb-3 relative z-10">Real-time Telemetry</h3>
              <p className="text-slate-400 text-sm leading-relaxed relative z-10">Monitor project velocity and team output with live-updating metrics, complex area charts, and immersive data visualizations.</p>
           </div>
           <div className="group p-8 rounded-3xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] hover:border-cyan-500/30 transition-all duration-500 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <Code2 className="text-cyan-400 mb-6 relative z-10" size={32} />
              <h3 className="text-xl font-display font-semibold text-white mb-3 relative z-10">Quantum Workflow</h3>
              <p className="text-slate-400 text-sm leading-relaxed relative z-10">Optimized for keyboard-first navigation. Create, assign, and transition engineering tasks in milliseconds with command palettes.</p>
           </div>
           <div className="group p-8 rounded-3xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] hover:border-purple-500/30 transition-all duration-500 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <Shield className="text-purple-400 mb-6 relative z-10" size={32} />
              <h3 className="text-xl font-display font-semibold text-white mb-3 relative z-10">Enterprise Grade</h3>
              <p className="text-slate-400 text-sm leading-relaxed relative z-10">Advanced role-based access control with granular permissions. Your mission-critical data is encrypted at rest and in transit.</p>
           </div>
        </div>
      </main>
    </div>
  );
}
