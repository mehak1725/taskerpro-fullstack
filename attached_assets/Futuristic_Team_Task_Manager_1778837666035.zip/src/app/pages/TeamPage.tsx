import { Search, UserPlus, MoreHorizontal, Mail, Shield } from "lucide-react";
import { MOCK_USERS } from "../data/mock";

export default function TeamPage() {
  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white mb-2">Team Network</h1>
          <p className="text-slate-400">Manage operatives and permissions.</p>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center bg-[#080b14]/80 border border-white/10 rounded-lg px-3 py-2 w-full md:w-64 focus-within:border-blue-500/50 focus-within:shadow-[0_0_10px_rgba(59,130,246,0.2)] transition-all">
            <Search size={16} className="text-slate-500" />
            <input 
              type="text" 
              placeholder="Search operatives..." 
              className="bg-transparent border-none outline-none ml-2 w-full text-sm text-slate-300 placeholder:text-slate-600"
            />
          </div>
          <button className="flex-shrink-0 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-[0_0_15px_rgba(59,130,246,0.3)] transition-all font-medium text-sm">
            <UserPlus size={18} />
            Invite Member
          </button>
        </div>
      </div>

      <div className="bg-[#080b14]/50 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/5 bg-white/[0.02]">
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Operative</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Role</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Last Active</th>
                <th className="px-6 py-4 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {MOCK_USERS.map((user) => (
                <tr key={user.id} className="hover:bg-white/[0.02] transition-colors group">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full border border-white/10 overflow-hidden relative">
                        <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                        <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-[#080b14] rounded-full" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{user.name}</p>
                        <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                          <Mail size={10} />
                          {user.name.toLowerCase().replace(' ', '.')}@nexus.io
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      {user.role === 'Admin' ? (
                        <Shield size={14} className="text-rose-400" />
                      ) : (
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                      )}
                      <span className={`text-sm ${user.role === 'Admin' ? 'text-rose-400 font-medium' : 'text-slate-300'}`}>
                        {user.role}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 font-medium">
                      Active
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">
                    Just now
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-slate-500 hover:text-white p-2 rounded-lg hover:bg-white/5 transition-colors opacity-0 group-hover:opacity-100">
                      <MoreHorizontal size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
