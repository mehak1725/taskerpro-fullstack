import { Link } from "react-router";
import { Plus, MoreVertical, LayoutGrid, List, BarChart3, AlertTriangle, ShieldCheck } from "lucide-react";
import { MOCK_PROJECTS, MOCK_USERS } from "../data/mock";

export default function ProjectsPage() {
  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white mb-2 tracking-tight">Active Projects</h1>
          <p className="text-slate-400 text-sm">Manage operational clusters and track structural health.</p>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex bg-[#080b14]/80 p-1 rounded-lg border border-white/10 backdrop-blur-md">
            <button className="p-1.5 bg-white/10 rounded-md text-white shadow-sm"><LayoutGrid size={16} /></button>
            <button className="p-1.5 text-slate-500 hover:text-white transition-colors"><List size={16} /></button>
          </div>
          <button className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-[0_0_20px_rgba(59,130,246,0.3)] transition-all font-medium text-sm border border-blue-500/50">
            <Plus size={16} />
            Initialize Project
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {MOCK_PROJECTS.map(project => (
          <Link 
            key={project.id} 
            to={`/app/projects/${project.id}`}
            className="group block relative bg-[#080b14]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-6 transition-all duration-300 hover:shadow-[0_0_40px_rgba(59,130,246,0.15)] overflow-hidden"
          >
            {/* Hover Glow Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/0 via-transparent to-cyan-500/0 opacity-0 group-hover:opacity-10 transition-opacity duration-500 pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/0 to-transparent group-hover:via-blue-500/50 transition-all duration-700" />
            
            <div className="flex justify-between items-start mb-5 relative z-10">
              <div className="flex items-center gap-3">
                 <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/10 flex items-center justify-center text-slate-300 group-hover:scale-105 group-hover:border-blue-500/30 group-hover:text-blue-400 transition-all duration-300 shadow-inner">
                   <LayoutGrid size={18} />
                 </div>
                 <div>
                    <h3 className="text-lg font-display font-bold text-white leading-tight group-hover:text-blue-100 transition-colors">{project.name}</h3>
                    <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500 mt-0.5">ID: {project.id.toUpperCase()}</div>
                 </div>
              </div>
              <button className="text-slate-500 hover:text-white p-1 rounded hover:bg-white/5 transition-colors" onClick={(e) => e.preventDefault()}>
                <MoreVertical size={18} />
              </button>
            </div>
            
            <div className="flex items-center gap-2 mb-6 relative z-10">
              <div className="inline-flex items-center px-2 py-0.5 rounded border border-white/10 bg-white/5 text-[10px] font-bold uppercase tracking-wider text-slate-300">
                {project.status}
              </div>
              <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[10px] font-bold uppercase tracking-wider ${
                 project.health === 'On Track' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' :
                 project.health === 'Warning' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' :
                 'bg-rose-500/10 border-rose-500/20 text-rose-400'
              }`}>
                {project.health === 'On Track' ? <ShieldCheck size={10}/> : project.health === 'Warning' ? <AlertTriangle size={10}/> : <BarChart3 size={10}/>}
                {project.health}
              </div>
            </div>

            <div className="space-y-2.5 relative z-10">
              <div className="flex justify-between items-end">
                <div className="text-xs text-slate-400 font-medium"><span className="text-white">{project.tasksCompleted}</span> / {project.tasksTotal} Tasks</div>
                <div className="text-xs font-bold text-blue-400">{project.progress}%</div>
              </div>
              <div className="w-full h-1.5 bg-black/50 border border-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 shadow-[0_0_10px_rgba(59,130,246,0.8)] relative"
                  style={{ width: `${project.progress}%` }}
                >
                   <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.2)_50%,transparent_75%)] bg-[length:20px_20px] animate-[shimmer_2s_linear_infinite]" />
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4 relative z-10">
              <div className="flex -space-x-2">
                {project.team.map((userId, i) => {
                  const user = MOCK_USERS.find(u => u.id === userId);
                  return (
                    <div key={i} className="w-7 h-7 rounded-full border border-[#080b14] overflow-hidden bg-black ring-1 ring-white/10 hover:z-20 hover:scale-110 transition-transform">
                      <img src={user?.avatar} alt={user?.name} className="w-full h-full object-cover opacity-90 hover:opacity-100" />
                    </div>
                  );
                })}
                <div className="w-7 h-7 rounded-full border border-[#080b14] bg-white/5 flex items-center justify-center text-[10px] text-slate-400 font-medium ring-1 ring-white/10 backdrop-blur-md">
                   +2
                </div>
              </div>
              <div className="text-[10px] font-mono text-slate-500 bg-black/40 px-2 py-1 rounded border border-white/5">
                 DUE: {project.deadline}
              </div>
            </div>
          </Link>
        ))}
      </div>
      
      {/* Global generic CSS for progress bar shimmer */}
      <style>{`
        @keyframes shimmer {
          0% { background-position: 20px 0; }
          100% { background-position: 0 0; }
        }
      `}</style>
    </div>
  );
}
