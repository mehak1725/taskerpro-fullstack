import { Activity, CheckCircle2, Clock, ListTodo, Zap, BrainCircuit, TrendingUp, TrendingDown, ArrowUpRight } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { ACTIVITY_TIMELINE, MOCK_USERS, AI_INSIGHTS, SPRINT_METRICS, WORKLOAD_DATA, MOCK_TASKS } from "../data/mock";
import { motion } from "motion/react";

export default function DashboardPage() {
  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white mb-2 tracking-tight">System Overview</h1>
          <p className="text-slate-400 text-sm">Welcome back, Commander. Here is your current operational telemetry.</p>
        </div>
        <div className="flex items-center gap-3 text-sm">
           <span className="text-slate-500">Sprint 42</span>
           <div className="h-4 w-px bg-white/10" />
           <span className="text-slate-300 font-medium">May 10 - May 24, 2026</span>
        </div>
      </div>

      {/* AI Insights Panel */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full relative overflow-hidden rounded-2xl p-px"
      >
        {/* Animated Gradient Border */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-cyan-400 to-purple-500 opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-cyan-400 to-purple-500 opacity-50 blur-md" />
        
        <div className="relative bg-[#080b14]/90 backdrop-blur-2xl rounded-[15px] p-5 border border-white/5 flex flex-col md:flex-row items-start md:items-center gap-4 shadow-2xl">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0">
            <BrainCircuit size={20} />
          </div>
          <div className="flex-1">
             <h4 className="text-white font-medium text-sm flex items-center gap-2 mb-1">
               AI Tactical Insight
               <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider bg-rose-500/10 text-rose-400 border border-rose-500/20">Critical</span>
             </h4>
             <p className="text-slate-400 text-sm leading-relaxed">{AI_INSIGHTS[0].description}</p>
          </div>
          <button className="flex-shrink-0 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-lg text-sm transition-all whitespace-nowrap shadow-sm">
             Take Action
          </button>
        </div>
      </motion.div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {[
          { label: "Active Nodes", value: "124", icon: ListTodo, color: "text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20", trend: "+12.5%", trendUp: true },
          { label: "Completed", value: "89", icon: CheckCircle2, color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20", trend: "+5.2%", trendUp: true },
          { label: "Velocity", value: "84pts", icon: Zap, color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20", trend: "-2.4%", trendUp: false },
          { label: "Blockers", value: "3", icon: Clock, color: "text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20", trend: "+1", trendUp: false },
        ].map((stat, i) => (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={i} 
            className="group relative bg-[#080b14]/60 backdrop-blur-xl border border-white/5 hover:border-white/10 rounded-2xl p-5 transition-all overflow-hidden"
          >
            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-${stat.color.split('-')[1]}-500/10 to-transparent blur-2xl rounded-full translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
            
            <div className="flex justify-between items-start mb-4 relative z-10">
              <div className={`w-10 h-10 rounded-lg ${stat.bg} ${stat.border} border flex items-center justify-center ${stat.color}`}>
                <stat.icon size={20} />
              </div>
              <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full bg-black/40 border border-white/5 ${stat.trendUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                {stat.trendUp ? <TrendingUp size={12}/> : <TrendingDown size={12}/>}
                {stat.trend}
              </div>
            </div>
            
            <div className="relative z-10">
              <p className="text-3xl font-display font-bold text-white mb-1 tracking-tight">{stat.value}</p>
              <p className="text-slate-500 text-xs font-semibold uppercase tracking-wider">{stat.label}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Velocity Chart */}
        <div className="lg:col-span-8 bg-[#080b14]/60 backdrop-blur-xl border border-white/5 rounded-2xl p-6 relative overflow-hidden flex flex-col">
          <div className="absolute top-0 left-1/4 w-1/2 h-px bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />
          
          <div className="flex justify-between items-start mb-6">
            <div>
              <h3 className="text-lg font-display font-semibold text-white mb-1">Sprint Velocity</h3>
              <p className="text-xs text-slate-400">Actual completion vs planned capacity</p>
            </div>
            <select className="bg-black/40 border border-white/10 text-white text-xs rounded-md px-2 py-1 outline-none">
               <option>Current Sprint</option>
               <option>Last Sprint</option>
            </select>
          </div>
          
          <div className="h-[280px] w-full mt-auto">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={SPRINT_METRICS} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorCapacity" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="day" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(8, 11, 20, 0.9)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', boxShadow: '0 10px 30px rgba(0,0,0,0.5)' }}
                  itemStyle={{ color: '#e2e8f0', fontSize: '12px', fontWeight: '500' }}
                  labelStyle={{ color: '#94a3b8', fontSize: '10px', textTransform: 'uppercase', marginBottom: '4px' }}
                />
                <Area type="monotone" dataKey="capacity" name="Capacity" stroke="#8b5cf6" strokeWidth={2} strokeDasharray="5 5" fill="url(#colorCapacity)" />
                <Area type="monotone" dataKey="actual" name="Completed" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorActual)" activeDot={{ r: 6, strokeWidth: 0, fill: '#60a5fa' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Workload Radar */}
        <div className="lg:col-span-4 bg-[#080b14]/60 backdrop-blur-xl border border-white/5 rounded-2xl p-6 flex flex-col relative overflow-hidden">
          <div className="absolute top-[-50px] right-[-50px] w-[150px] h-[150px] bg-cyan-500/10 blur-[60px] rounded-full" />
          
          <h3 className="text-lg font-display font-semibold text-white mb-1">Team Workload</h3>
          <p className="text-xs text-slate-400 mb-6">Distribution across disciplines</p>
          
          <div className="flex-1 w-full min-h-[220px] -mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={WORKLOAD_DATA}>
                <PolarGrid stroke="#1e293b" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Radar name="Points" dataKey="A" stroke="#06b6d4" strokeWidth={2} fill="#06b6d4" fillOpacity={0.3} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(8, 11, 20, 0.9)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                  itemStyle={{ color: '#06b6d4', fontSize: '12px' }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Recent Tasks */}
        <div className="lg:col-span-7 bg-[#080b14]/60 backdrop-blur-xl border border-white/5 rounded-2xl p-6">
          <div className="flex justify-between items-center mb-6">
             <h3 className="text-lg font-display font-semibold text-white">Priority Queue</h3>
             <button className="text-xs font-medium text-blue-400 hover:text-blue-300 flex items-center gap-1">
               View All <ArrowUpRight size={14}/>
             </button>
          </div>
          
          <div className="space-y-3">
            {MOCK_TASKS.slice(0, 4).map((task) => {
              const assignee = MOCK_USERS.find(u => u.id === task.assigneeId);
              return (
                <div key={task.id} className="group flex items-center gap-4 p-3 rounded-xl bg-black/40 border border-white/5 hover:border-blue-500/30 transition-all hover:shadow-[0_0_15px_rgba(59,130,246,0.1)]">
                   <div className={`w-2 h-2 rounded-full shrink-0 ${task.status === 'Completed' ? 'bg-emerald-500' : task.status === 'In Progress' ? 'bg-blue-500 animate-pulse' : 'bg-slate-600'}`} />
                   
                   <div className="flex-1 min-w-0">
                     <p className="text-sm font-medium text-white truncate group-hover:text-blue-100 transition-colors">{task.title}</p>
                     <div className="flex items-center gap-3 mt-1.5">
                       <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">{task.projectId === 'p1' ? 'NOVA' : 'API'}</span>
                       <div className="flex gap-1.5">
                         {task.tags.slice(0, 1).map(tag => (
                           <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 border border-white/5">{tag}</span>
                         ))}
                       </div>
                     </div>
                   </div>
                   
                   <div className="flex items-center gap-4 shrink-0">
                     <span className={`text-[10px] px-2 py-1 rounded uppercase font-bold tracking-wider ${
                        task.priority === 'High' || task.priority === 'Urgent' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 
                        task.priority === 'Medium' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 
                        'bg-slate-500/10 text-slate-400 border border-slate-500/20'
                     }`}>{task.priority}</span>
                     <div className="w-7 h-7 rounded-full overflow-hidden border border-white/10 bg-[#080b14]">
                        <img src={assignee?.avatar} alt="Assignee" className="w-full h-full object-cover" />
                     </div>
                   </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Activity Feed */}
        <div className="lg:col-span-5 bg-[#080b14]/60 backdrop-blur-xl border border-white/5 rounded-2xl p-6 flex flex-col">
          <h3 className="text-lg font-display font-semibold text-white mb-6">Live Telemetry</h3>
          <div className="flex-1 space-y-6 overflow-y-auto pr-2 scrollbar-hide">
            {ACTIVITY_TIMELINE.map((activity, i) => {
              const user = MOCK_USERS.find(u => u.id === activity.userId);
              return (
                <div key={i} className="flex gap-4 relative group">
                  {i !== ACTIVITY_TIMELINE.length - 1 && (
                    <div className="absolute top-8 left-[17px] w-px h-[calc(100%+8px)] bg-gradient-to-b from-white/10 to-transparent" />
                  )}
                  <div className="relative w-9 h-9 rounded-full border border-white/10 overflow-hidden shrink-0 z-10 bg-[#080b14] group-hover:border-blue-500/50 transition-colors">
                    <img src={user?.avatar} alt={user?.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="pt-0.5">
                    <p className="text-sm text-slate-300 leading-snug">
                      <span className="font-semibold text-white">{user?.name}</span> {activity.action} <span className="text-blue-400 font-medium hover:underline cursor-pointer">{activity.target}</span>
                    </p>
                    <p className="text-xs text-slate-500 mt-1 font-mono">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
