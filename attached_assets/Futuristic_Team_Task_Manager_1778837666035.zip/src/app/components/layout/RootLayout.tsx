import { Outlet } from "react-router";

export default function RootLayout() {
  return (
    <div className="min-h-screen bg-[#03050a] text-slate-200 font-sans selection:bg-blue-500/30">
      <Outlet />
    </div>
  );
}
