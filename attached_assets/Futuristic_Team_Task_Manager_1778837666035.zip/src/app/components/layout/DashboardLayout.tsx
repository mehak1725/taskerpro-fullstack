import { Outlet, NavLink, useLocation } from "react-router";
import { 
  LayoutDashboard, 
  FolderKanban, 
  Users, 
  Settings, 
  LogOut,
  Bell,
  Search,
  Menu,
  Command,
  Activity
} from "lucide-react";

export default function DashboardLayout() {
  const location = useLocation();

  const navItems = [
    { path: "/app/dashboard", icon: LayoutDashboard, label: "Command Center" },
    { path: "/app/projects", icon: FolderKanban, label: "Active Projects" },
    { path: "/app/team", icon: Users, label: "Operatives" },
    { path: "/app/settings", icon: Settings, label: "System Config" },
  ];

  return (
    <div className="flex h-screen bg-[#010205] text-slate-300 font-sans overflow-hidden selection:bg-blue-500/30">
      
      {/* Background ambient glows for the whole dashboard */}
      <div className="fixed top-[-20%] left-[-10%] w-[50%] h-[50%] bg-blue-900/10 blur-[120px] rounded-full pointer-events-none mix-blend-screen" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-900/5 blur-[100px] rounded-full pointer-events-none mix-blend-screen" />

      {/* Sidebar */}
      <aside className="w-72 flex-shrink-0 bg-[#080b14]/80 backdrop-blur-2xl border-r border-white/5 flex flex-col hidden md:flex relative z-20 shadow-[4px_0_24px_rgba(0,0,0,0.4)]">
        <div className="h-16 flex items-center px-6 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="relative w-7 h-7 rounded-lg bg-blue-600/20 flex items-center justify-center border border-blue-500/50 shadow-[0_0_15px_rgba(59,130,246,0.3)]">
              <div className="w-2.5 h-2.5 bg-blue-400 rounded-sm shadow-[0_0_8px_rgba(59,130,246,1)]" />
            </div>
            <span className="font-display font-bold text-lg tracking-widest text-white">NEXUS</span>
          </div>
        </div>

        <div className="px-6 py-4">
          <div className="flex items-center justify-between px-3 py-2 bg-white/[0.02] border border-white/5 rounded-lg mb-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
              <Activity size={14} className="text-emerald-400" />
              SYSTEM ONLINE
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1.5 overflow-y-auto scrollbar-hide">
          <div className="text-[10px] font-bold tracking-wider text-slate-500 uppercase px-3 pb-2 pt-4">Main Menu</div>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `group relative flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-300 ${
                  isActive
                    ? "bg-blue-600/10 text-blue-300 border border-blue-500/20 shadow-[inset_0_0_20px_rgba(59,130,246,0.05)]"
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5 border border-transparent"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-blue-500 rounded-r-full shadow-[0_0_10px_rgba(59,130,246,0.8)]" />
                  )}
                  <item.icon size={18} className={isActive ? "text-blue-400" : "text-slate-500 group-hover:text-slate-300 transition-colors"} />
                  <span className="font-medium text-sm">{item.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 mt-auto border-t border-white/5">
          {/* User Mini Profile */}
          <div className="flex items-center gap-3 px-3 py-3 rounded-xl bg-white/[0.02] border border-white/5 mb-2 cursor-pointer hover:bg-white/[0.04] transition-colors">
             <div className="w-8 h-8 rounded-full overflow-hidden border border-white/10">
               <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop" alt="User" />
             </div>
             <div className="flex-1 min-w-0">
               <p className="text-sm font-medium text-white truncate">Alex Rivera</p>
               <p className="text-[10px] text-slate-400 truncate">Lead Architect</p>
             </div>
          </div>
          
          <button className="flex items-center gap-3 px-3 py-2.5 w-full text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors border border-transparent hover:border-rose-500/20">
            <LogOut size={16} />
            <span className="font-medium text-sm">Disconnect</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative min-w-0 z-10">
        
        {/* Top Navbar */}
        <header className="h-16 flex-shrink-0 border-b border-white/5 bg-[#080b14]/60 backdrop-blur-xl flex items-center justify-between px-8 z-30">
          <div className="flex items-center gap-4 md:hidden">
            <button className="text-slate-400 hover:text-white">
              <Menu size={24} />
            </button>
          </div>

          <div className="hidden md:flex items-center bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 w-[400px] focus-within:border-blue-500/50 focus-within:ring-1 focus-within:ring-blue-500/30 transition-all shadow-inner">
            <Search size={14} className="text-slate-500" />
            <input 
              type="text" 
              placeholder="Search telemetry, tasks, or operatives..." 
              className="bg-transparent border-none outline-none ml-2 w-full text-sm text-slate-300 placeholder:text-slate-600"
            />
            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/5 text-[10px] text-slate-500 font-mono ml-auto">
              <Command size={10}/> K
            </div>
          </div>

          <div className="flex items-center gap-5">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400/80 text-xs font-medium cursor-help">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              1 Server Warning
            </div>
            
            <button className="relative p-2 text-slate-400 hover:text-white transition-colors hover:bg-white/5 rounded-full">
              <Bell size={18} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full shadow-[0_0_8px_rgba(59,130,246,0.8)] border-2 border-[#080b14]" />
            </button>
          </div>
        </header>

        {/* Page Content Scroll Area */}
        <div className="flex-1 overflow-auto p-8 z-10 scrollbar-hide">
          <div className="max-w-[1400px] mx-auto">
            <Outlet />
          </div>
        </div>
      </main>
    </div>
  );
}
